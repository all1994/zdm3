export { default as PDFAnnotation } from 'src/core/annotation/PDFAnnotation';
export { default as PDFWidgetAnnotation } from 'src/core/annotation/PDFWidgetAnnotation';
export { default as AppearanceCharacteristics } from 'src/core/annotation/AppearanceCharacteristics';
export * from 'src/core/annotation/flags';
