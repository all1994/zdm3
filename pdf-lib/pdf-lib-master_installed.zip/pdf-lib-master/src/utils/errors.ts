export const error = (msg: string) => {
  throw new Error(msg);
};
