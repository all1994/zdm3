export enum ImageAlignment {
  Left = 0,
  Center = 1,
  Right = 2,
}
