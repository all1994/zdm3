LICENSE
=======

The PDF Association provides these example PDF 2.0 files under the Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0) license. Please see https://creativecommons.org/licenses/by-sa/4.0/ for further details.

CONTRIBUTIONS
=============

We welcome your contributions of additional examples!
For any files, materials, pull requests or other contributions you offer for this project: you hereby grant the PDF Association copyright to these contributions, as well as grant permission for the PDF Association to license your contributions under the same license as the other contents of this repository. The PDF Association does not request an exclusive copyright. We make this request so that we can offer your contribution under the same Creative Commons license we are using for the rest of these examples and materials.
