# 🚨⚠️ STOP!!! ⚠️🚨

👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇

**All new issues must be created from a template: https://github.com/Hopding/pdf-lib/issues/new/choose**

👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆

* If you create an issue without using a template it will be closed without comment.
* Do not create an issue if you have a question. Open a [discussion](https://github.com/Hopding/pdf-lib/discussions/new) instead.
* If none of the templates match what you're looking for, then you should not create an issue. Start a [discussion](https://github.com/Hopding/pdf-lib/discussions/new) instead.

See [MAINTAINERSHIP.md#issues](https://github.com/Hopding/pdf-lib/blob/master/docs/MAINTAINERSHIP.md#issues) for more information.
